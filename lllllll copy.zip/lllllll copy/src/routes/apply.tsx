import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useStore, useT } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { CheckCircle2, Plus, Trash2, Upload, ExternalLink } from "lucide-react";
import type { Applicant, DegreeLevel, FundingPreference } from "@/lib/mockData";

export const Route = createFileRoute("/apply")({
  head: () => ({
    meta: [
      { title: "Apply — YNK Opportunities" },
      { name: "description", content: "Tell us about you and we'll match you to global opportunities." },
    ],
  }),
  component: ApplyPage,
});

const DEGREE_LEVELS: DegreeLevel[] = ["Diploma", "Bachelor", "Master", "PhD", "Short course"];
const EXPERIENCE_OPTIONS = [
  "Research assistant",
  "Published research",
  "Internship",
  "Volunteer / NGO work",
  "Founded a startup",
  "Competition winner",
  "Teaching",
  "Leadership role",
];
const LANGUAGE_EXAMS = ["IELTS", "TOEFL", "PTE", "Duolingo", "Cambridge", "Previous study in English", "Other"];
const COUNTRIES = [
  "United Kingdom",
  "Germany",
  "Netherlands",
  "Sweden",
  "United States",
  "France",
  "Japan",
  "China",
  "Turkey",
  "Austria",
  "Saudi Arabia",
];
const FUNDING_PREFERENCE_OPTIONS: FundingPreference[] = ["Full scholarship only", "Self-funded", "Open to both"];

interface FormData {
  fullName: string;
  email: string;
  phone: string;
  city: string;
  gender: "F" | "M" | "Other";
  dateOfBirth: string;
  degreeLevel: DegreeLevel;
  field: string;
  university: string;
  gpa: string;
  studyStartDate: string;
  studyGraduationDate: string;
  additionalDegrees: { level: DegreeLevel; field: string; university: string; startDate: string; graduationDate: string; gpa: string }[];
  targetLevel: DegreeLevel;
  targetField: string;
  targetCountries: string[];
  targetRegionsText: string;
  targetUniversitiesText: string;
  englishLevel: "A2" | "B1" | "B2" | "C1" | "C2";
  languageTests: { exam: string; score: string; details: string; fileName?: string }[];
  experienceEntries: {
    category: string;
    role: string;
    organization: string;
    location: string;
    period: string;
    collaborators: string;
    details: string;
  }[];
  fundingPreference: FundingPreference;
  notes: string;
  documents: { name: string; kind: string; size?: number; fileType?: string }[];
  documentUploadSlots: number;
}

const EMPTY: FormData = {
  fullName: "",
  email: "",
  phone: "",
  city: "",
  gender: "F",
  dateOfBirth: "",
  degreeLevel: "Bachelor",
  field: "",
  university: "",
  gpa: "",
  studyStartDate: "",
  studyGraduationDate: "",
  additionalDegrees: [],
  targetLevel: "Master",
  targetField: "",
  targetCountries: ["", "", ""],
  targetRegionsText: "",
  targetUniversitiesText: "",
  englishLevel: "B2",
  languageTests: [{ exam: "IELTS", score: "", details: "" }],
  experienceEntries: [
    {
      category: EXPERIENCE_OPTIONS[0],
      role: "",
      organization: "",
      location: "",
      period: "",
      collaborators: "",
      details: "",
    },
  ],
  fundingPreference: "Full scholarship only",
  notes: "",
  documents: [],
  documentUploadSlots: 1,
};

function ApplyPage() {
  const t = useT();
  const { addApplicant, lang } = useStore();
  const [step, setStep] = useState(0);
  const [data, setData] = useState<FormData>(EMPTY);
  const [done, setDone] = useState(false);

  const steps = useMemo(
    () => [
      t("form.identity"),
      t("form.academic"),
      t("form.target"),
      t("form.language"),
      t("form.experience"),
      t("form.funding"),
      t("form.docs"),
    ],
    [lang],
  );

  const set = <K extends keyof FormData>(k: K, v: FormData[K]) => setData((d) => ({ ...d, [k]: v }));

  const addDegree = () => {
    set("additionalDegrees", [...data.additionalDegrees, { level: "Bachelor", field: "", university: "", startDate: "", graduationDate: "", gpa: "" }]);
  };

  const updateDegree = (index: number, key: keyof FormData["additionalDegrees"][number], value: string) => {
    const next = [...data.additionalDegrees];
    next[index] = { ...next[index], [key]: value } as FormData["additionalDegrees"][number];
    set("additionalDegrees", next);
  };

  const updateCountry = (index: number, value: string) => {
    const next = [...data.targetCountries];
    next[index] = value;
    set("targetCountries", next);
  };

  const addCountryChip = (country: string) => {
    const next = [...data.targetCountries];
    const idx = next.findIndex((entry) => !entry.trim());
    if (idx >= 0) {
      next[idx] = country;
    } else {
      next[0] = country;
    }
    set("targetCountries", next.slice(0, 3));
  };

  const addLanguageTest = () => {
    set("languageTests", [...data.languageTests, { exam: "IELTS", score: "", details: "" }]);
  };

  const updateLanguageTest = (index: number, key: keyof FormData["languageTests"][number], value: string) => {
    const next = [...data.languageTests];
    next[index] = { ...next[index], [key]: value } as FormData["languageTests"][number];
    set("languageTests", next);
  };

  const addExperienceEntry = () => {
    set("experienceEntries", [
      ...data.experienceEntries,
      {
        category: EXPERIENCE_OPTIONS[0],
        role: "",
        organization: "",
        location: "",
        period: "",
        collaborators: "",
        details: "",
      },
    ]);
  };

  const updateExperienceEntry = (index: number, key: keyof FormData["experienceEntries"][number], value: string) => {
    const next = [...data.experienceEntries];
    next[index] = { ...next[index], [key]: value } as FormData["experienceEntries"][number];
    set("experienceEntries", next);
  };

  const addDocumentUpload = () => {
    set("documentUploadSlots", data.documentUploadSlots + 1);
  };

  const handleDocumentUpload = (name: string, kind: string, size?: number, fileType?: string) => {
    if (!name) return;
    const maxBytes = 5 * 1024 * 1024;
    if (size && size > maxBytes) {
      toast.error("Documents must be 5 MB or smaller.");
      return;
    }
    if (fileType && fileType !== "application/pdf" && !name.toLowerCase().endsWith(".pdf")) {
      toast.error("Only PDF files are accepted for uploads.");
      return;
    }
    set("documents", [...data.documents, { name, kind, size, fileType }]);
    toast.success(`Added ${name}`);
  };

  const submit = () => {
    const a: Applicant = {
      id: `a_${Date.now()}`,
      fullName: data.fullName || "Untitled applicant",
      email: data.email,
      phone: data.phone,
      country: "Iraq",
      city: data.city,
      gender: data.gender,
      dateOfBirth: data.dateOfBirth,
      degreeLevel: data.degreeLevel,
      field: data.field,
      university: data.university,
      gpa: parseFloat(data.gpa) || 0,
      targetLevel: data.targetLevel,
      targetField: data.targetField,
      targetCountries: data.targetCountries.filter(Boolean),
      targetRegions: data.targetRegionsText.split(/[\n,]+/).map((x) => x.trim()).filter(Boolean),
      targetUniversities: data.targetUniversitiesText.split(/[\n,]+/).map((x) => x.trim()).filter(Boolean),
      languages: [
        { name: "Kurdish", level: "C2" },
        { name: "English", level: data.englishLevel },
      ],
      languageTests: data.languageTests.filter((entry) => entry.exam || entry.score || entry.details || entry.fileName),
      ielts: data.languageTests.find((entry) => entry.exam === "IELTS")?.score ? parseFloat(data.languageTests.find((entry) => entry.exam === "IELTS")?.score || "") : undefined,
      experience: data.experienceEntries.map((entry) => entry.category).filter(Boolean),
      experienceDetails: data.experienceEntries.filter((entry) => entry.category || entry.role || entry.organization || entry.details),
      fundingPreference: [data.fundingPreference],
      notes: data.notes,
      documents: data.documents,
      studyStartDate: data.studyStartDate || undefined,
      studyGraduationDate: data.studyGraduationDate || undefined,
      additionalDegrees: data.additionalDegrees.filter((entry) => entry.level || entry.field || entry.university || entry.gpa),
      createdAt: new Date().toISOString(),
      status: "New",
    };
    addApplicant(a);
    setDone(true);
    toast.success(t("form.done"));
  };

  if (done) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <div className="rounded-xl border border-border bg-card p-8 text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-full bg-primary/10 text-primary">
            <CheckCircle2 className="size-7" />
          </div>
          <h1 className="mt-4 text-2xl font-semibold">{t("form.done")}</h1>
          <p className="mt-2 text-sm text-muted-foreground">{t("form.doneBody")}</p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <Button asChild>
              <Link to="/admin">See it in Admin</Link>
            </Button>
            <Button variant="outline" onClick={() => { setData(EMPTY); setStep(0); setDone(false); }}>
              Submit another
            </Button>
          </div>
        </div>
      </main>
    );
  }

  const pct = ((step + 1) / steps.length) * 100;

  return (
    <main className="mx-auto max-w-2xl px-4 py-10 sm:px-6">
      <div className="mb-6">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>
            {t("form.step")} {step + 1} {t("form.of")} {steps.length} — <span className="text-foreground">{steps[step]}</span>
          </span>
          <span>{Math.round(pct)}%</span>
        </div>
        <Progress value={pct} className="mt-2 h-1.5" />
      </div>

      <div className="rounded-xl border border-border bg-card p-6">
        {step === 0 && (
          <div className="grid gap-4">
            <Field label="Full name">
              <Input value={data.fullName} onChange={(e) => set("fullName", e.target.value)} placeholder="e.g. Shan Ibrahim" />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Email">
                <Input type="email" value={data.email} onChange={(e) => set("email", e.target.value)} />
              </Field>
              <Field label="Phone">
                <Input value={data.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+964 …" />
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="City">
                <Input value={data.city} onChange={(e) => set("city", e.target.value)} />
              </Field>
              <Field label="Gender">
                <Select value={data.gender} onValueChange={(v) => set("gender", v as FormData["gender"])}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="F">Female</SelectItem>
                    <SelectItem value="M">Male</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Date of birth">
                <Input type="date" value={data.dateOfBirth} onChange={(e) => set("dateOfBirth", e.target.value)} />
              </Field>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Current level">
                <Select value={data.degreeLevel} onValueChange={(v) => set("degreeLevel", v as DegreeLevel)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DEGREE_LEVELS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Field of study">
                <Input value={data.field} onChange={(e) => set("field", e.target.value)} placeholder="e.g. Computer Science" />
              </Field>
            </div>
            <Field label="University">
              <Input value={data.university} onChange={(e) => set("university", e.target.value)} />
            </Field>
            <Field label="GPA (out of 4)">
              <Input type="number" step="0.1" min="0" max="4" value={data.gpa} onChange={(e) => set("gpa", e.target.value)} />
            </Field>
            <a href="https://www.gpacalculator.io" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
              <ExternalLink className="size-4" /> Open GPA calculator
            </a>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Study start date">
                <Input type="date" value={data.studyStartDate} onChange={(e) => set("studyStartDate", e.target.value)} />
              </Field>
              <Field label="Expected graduation date">
                <Input type="date" value={data.studyGraduationDate} onChange={(e) => set("studyGraduationDate", e.target.value)} />
              </Field>
            </div>
            <div className="rounded-md border border-border p-3">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-sm font-medium">Additional degrees (optional)</p>
                <Button type="button" variant="outline" size="sm" onClick={addDegree}>
                  <Plus className="mr-2 size-4" /> Add degree
                </Button>
              </div>
              {data.additionalDegrees.length === 0 ? (
                <p className="text-sm text-muted-foreground">You can add another degree if you have one.</p>
              ) : (
                data.additionalDegrees.map((degree, index) => (
                  <div key={index} className="mb-3 rounded-md border border-border/70 bg-secondary/20 p-3">
                    <div className="mb-3 flex items-center justify-between">
                      <p className="text-sm font-medium">Degree {index + 2}</p>
                      <Button type="button" variant="ghost" size="sm" onClick={() => set("additionalDegrees", data.additionalDegrees.filter((_, i) => i !== index))}>
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="Level">
                        <Select value={degree.level} onValueChange={(v) => updateDegree(index, "level", v as DegreeLevel)}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {DEGREE_LEVELS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </Field>
                      <Field label="Field">
                        <Input value={degree.field} onChange={(e) => updateDegree(index, "field", e.target.value)} />
                      </Field>
                    </div>
                    <Field label="University">
                      <Input value={degree.university} onChange={(e) => updateDegree(index, "university", e.target.value)} />
                    </Field>
                    <div className="mt-3 grid gap-3 sm:grid-cols-3">
                      <Field label="Start date">
                        <Input type="date" value={degree.startDate} onChange={(e) => updateDegree(index, "startDate", e.target.value)} />
                      </Field>
                      <Field label="Graduation date">
                        <Input type="date" value={degree.graduationDate} onChange={(e) => updateDegree(index, "graduationDate", e.target.value)} />
                      </Field>
                      <Field label="GPA">
                        <Input type="number" step="0.1" min="0" max="4" value={degree.gpa} onChange={(e) => updateDegree(index, "gpa", e.target.value)} />
                      </Field>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Target level">
                <Select value={data.targetLevel} onValueChange={(v) => set("targetLevel", v as DegreeLevel)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DEGREE_LEVELS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Target field">
                <Input value={data.targetField} onChange={(e) => set("targetField", e.target.value)} placeholder="e.g. Data Science" />
              </Field>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {data.targetCountries.map((country, index) => (
                <Field key={index} label={`Target country ${index + 1}`}>
                  <Input value={country} onChange={(e) => updateCountry(index, e.target.value)} placeholder="Type a country" />
                </Field>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              {COUNTRIES.map((country) => (
                <button key={country} type="button" onClick={() => addCountryChip(country)} className="rounded-full border border-border bg-background px-3 py-1 text-xs text-muted-foreground transition-colors hover:bg-secondary">
                  {country}
                </button>
              ))}
            </div>
            <Field label="Target continent / region (optional)">
              <Input value={data.targetRegionsText} onChange={(e) => set("targetRegionsText", e.target.value)} placeholder="e.g. Europe, MENA, Asia" />
            </Field>
            <Field label="Target universities (optional)">
              <Input value={data.targetUniversitiesText} onChange={(e) => set("targetUniversitiesText", e.target.value)} placeholder="Type each university on a new line" />
            </Field>
          </div>
        )}

        {step === 3 && (
          <div className="grid gap-4">
            <Field label="English level (CEFR)">
              <Select value={data.englishLevel} onValueChange={(v) => set("englishLevel", v as FormData["englishLevel"])}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["A2", "B1", "B2", "C1", "C2"].map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <div className="rounded-md border border-border p-3">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-sm font-medium">Language scores / other exams</p>
                <Button type="button" variant="outline" size="sm" onClick={addLanguageTest}>
                  <Plus className="mr-2 size-4" /> Add another test
                </Button>
              </div>
              {data.languageTests.map((entry, index) => (
                <div key={index} className="mb-3 rounded-md border border-border/70 bg-secondary/20 p-3">
                  <Field label="Exam type">
                    <Select value={entry.exam} onValueChange={(value) => updateLanguageTest(index, "exam", value)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {LANGUAGE_EXAMS.map((exam) => <SelectItem key={exam} value={exam}>{exam}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </Field>
                  <div className="mt-3 grid gap-3 sm:grid-cols-2">
                    <Field label="Score / band / result">
                      <Input value={entry.score} onChange={(e) => updateLanguageTest(index, "score", e.target.value)} placeholder="e.g. 7.0 or 95" />
                    </Field>
                    <Field label="Details">
                      <Input value={entry.details} onChange={(e) => updateLanguageTest(index, "details", e.target.value)} placeholder="e.g. taken in 2024" />
                    </Field>
                  </div>
                  <label className="mt-3 flex cursor-pointer items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-secondary">
                    <Upload className="size-4" /> Upload score file (PDF, max 5MB)
                    <input
                      type="file"
                      accept="application/pdf"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          handleDocumentUpload(file.name, "Language score", file.size, file.type);
                          updateLanguageTest(index, "fileName", file.name);
                          e.target.value = "";
                        }
                      }}
                    />
                  </label>
                  {entry.fileName && <p className="mt-2 text-xs text-muted-foreground">Uploaded: {entry.fileName}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="grid gap-3">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">Add each experience one by one with more detail.</p>
              <Button type="button" variant="outline" size="sm" onClick={addExperienceEntry}>
                <Plus className="mr-2 size-4" /> Add experience
              </Button>
            </div>
            {data.experienceEntries.map((entry, index) => (
              <div key={index} className="rounded-md border border-border p-3">
                <Field label="Experience type">
                  <Select value={entry.category} onValueChange={(value) => updateExperienceEntry(index, "category", value)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {EXPERIENCE_OPTIONS.map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </Field>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <Field label="Role / title">
                    <Input value={entry.role} onChange={(e) => updateExperienceEntry(index, "role", e.target.value)} />
                  </Field>
                  <Field label="Organization">
                    <Input value={entry.organization} onChange={(e) => updateExperienceEntry(index, "organization", e.target.value)} />
                  </Field>
                </div>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <Field label="Where">
                    <Input value={entry.location} onChange={(e) => updateExperienceEntry(index, "location", e.target.value)} />
                  </Field>
                  <Field label="When / period">
                    <Input value={entry.period} onChange={(e) => updateExperienceEntry(index, "period", e.target.value)} />
                  </Field>
                </div>
                <Field label="With whom / collaborators">
                  <Input value={entry.collaborators} onChange={(e) => updateExperienceEntry(index, "collaborators", e.target.value)} />
                </Field>
                <Field label="Details">
                  <Textarea rows={3} value={entry.details} onChange={(e) => updateExperienceEntry(index, "details", e.target.value)} />
                </Field>
              </div>
            ))}
          </div>
        )}

        {step === 5 && (
          <div className="grid gap-4">
            <Field label="Funding preference">
              <Select value={data.fundingPreference} onValueChange={(value) => set("fundingPreference", value as FundingPreference)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FUNDING_PREFERENCE_OPTIONS.map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Anything else we should know?">
              <Textarea rows={4} value={data.notes} onChange={(e) => set("notes", e.target.value)} />
            </Field>
          </div>
        )}

        {step === 6 && (
          <div className="grid gap-4">
            <p className="text-sm text-muted-foreground">Upload as many PDF documents as you need. Each file must be 5 MB or smaller.</p>
            {Array.from({ length: data.documentUploadSlots }).map((_, index) => (
              <FakeUpload key={index} onFile={(name, kind, size, fileType) => handleDocumentUpload(name, kind, size, fileType)} />
            ))}
            <Button type="button" variant="outline" onClick={addDocumentUpload}>
              <Plus className="mr-2 size-4" /> Add another document
            </Button>
            {data.documents.length > 0 && (
              <ul className="grid gap-2">
                {data.documents.map((d, i) => (
                  <li key={i} className="flex items-center justify-between rounded-md border border-border bg-secondary/30 px-3 py-2 text-sm">
                    <span className="flex items-center gap-2">
                      <CheckCircle2 className="size-4 text-primary" />
                      {d.name}
                    </span>
                    <Badge variant="secondary">{d.kind}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        <div className="mt-6 flex items-center justify-between">
          <Button variant="ghost" disabled={step === 0} onClick={() => setStep((s) => Math.max(0, s - 1))}>
            {t("form.back")}
          </Button>
          {step < steps.length - 1 ? (
            <Button onClick={() => setStep((s) => Math.min(steps.length - 1, s + 1))}>{t("form.next")}</Button>
          ) : (
            <Button onClick={submit}>{t("form.submit")}</Button>
          )}
        </div>
      </div>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-1.5">
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function FakeUpload({ onFile }: { onFile: (name: string, kind: string, size?: number, fileType?: string) => void }) {
  const [kind, setKind] = useState("CV");
  return (
    <div className="grid gap-3 rounded-lg border border-dashed border-border p-4">
      <div className="flex items-center gap-3">
        <Select value={kind} onValueChange={setKind}>
          <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            {["CV", "Transcript", "Passport", "Writing sample", "Portfolio", "Other"].map((k) => (
              <SelectItem key={k} value={k}>{k}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-secondary">
          <Upload className="size-4" /> Choose file
          <input
            type="file"
            className="hidden"
            accept="application/pdf"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) {
                onFile(f.name, kind, f.size, f.type);
                e.target.value = "";
              }
            }}
          />
        </label>
      </div>
      <p className="text-xs text-muted-foreground">PDF only, max 5 MB. Files are still demo-only.</p>
    </div>
  );
}
