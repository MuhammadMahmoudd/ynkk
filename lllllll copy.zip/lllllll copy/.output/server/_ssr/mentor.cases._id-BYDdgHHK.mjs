import { M as notFound, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useStore } from "./store-DyQeOvs3.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { S as ArrowLeft, b as Check, c as MessageCircle, g as CloudUpload, p as FileText, t as X } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./mentor.cases._id-8ocbOuEq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mentor.cases._id-BYDdgHHK.js
var import_jsx_runtime = require_jsx_runtime();
function MentorCaseDetail() {
	const { id } = Route.useParams();
	const { applicants, opportunities, matches, setMatchDecision, setMatchNote, setMentorReport, mentors, activeMentorId } = useStore();
	const a = applicants.find((x) => x.id === id);
	const whatsAppLink = `https://wa.me/${(a?.phone || "").replace(/[^0-9]/g, "")}`;
	if (!a) throw notFound();
	const mentorName = mentors.find((m) => m.id === activeMentorId)?.name || "Mentor";
	const applicantMatches = matches.filter((m) => m.applicantId === a.id).sort((x, y) => y.score - x.score);
	const approved = applicantMatches.filter((m) => m.mentorDecision === "approved").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-4xl px-4 py-6 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/mentor",
				className: "mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Back to my cases"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4 rounded-xl border border-border bg-card p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold",
						children: a.fullName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							a.targetLevel,
							" · ",
							a.targetField,
							" · Wants: ",
							a.targetCountries.join(", ")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "secondary",
								children: ["GPA ", a.gpa.toFixed(1)]
							}),
							a.ielts && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "secondary",
								children: ["IELTS ", a.ielts]
							}),
							a.fundingPreference.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: f
							}, f))
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: whatsAppLink,
							target: "_blank",
							rel: "noreferrer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "mr-2 size-4" }), " Call customer"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/mentor/cases/$id/export",
							params: { id: a.id },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" }), " Export view"]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-xl border border-border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold",
						children: "Customer data"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Mentor can review the whole profile and upload a shortlist report for admin."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex cursor-pointer items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-secondary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-4" }),
							" Upload report",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								className: "hidden",
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) {
										setMentorReport(a.id, {
											title: `Shortlist report for ${a.fullName}`,
											fileName: f.name,
											uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
											note: `Uploaded by ${mentorName}`
										});
										toast.success(`Uploaded ${f.name}`);
										e.target.value = "";
									}
								}
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3 text-sm text-muted-foreground sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: "Preferred countries:"
							}),
							" ",
							a.targetCountries.join(", ") || "—"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: "Regions:"
							}),
							" ",
							(a.targetRegions || []).join(", ") || "—"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: "Universities:"
							}),
							" ",
							(a.targetUniversities || []).join(", ") || "—"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: "Documents:"
							}),
							" ",
							a.documents.length
						] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold",
					children: "Shortlist"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [
						approved,
						"/",
						applicantMatches.length,
						" approved"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-3",
				children: applicantMatches.map((m) => {
					const op = opportunities.find((o) => o.id === m.opportunityId);
					const decision = m.mentorDecision;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: `rounded-xl border p-4 transition-colors ${decision === "approved" ? "border-primary/50 bg-primary/5" : decision === "rejected" ? "border-border bg-secondary/20 opacity-60" : "border-border bg-card"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "truncate text-base font-semibold",
											children: op.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											variant: "outline",
											className: "shrink-0",
											children: [m.score, " match"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [
											op.provider,
											" · ",
											op.country,
											" · ",
											op.fundingType,
											" · Deadline",
											" ",
											new Date(op.deadline).toLocaleDateString(void 0, {
												month: "short",
												day: "numeric"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted-foreground",
										children: op.summary
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-2 flex flex-wrap gap-1.5",
										children: m.reasons.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "rounded bg-secondary px-2 py-0.5 text-[11px] text-muted-foreground",
											children: r
										}, i))
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: decision === "approved" ? "default" : "outline",
									onClick: () => setMatchDecision(a.id, op.id, decision === "approved" ? null : "approved"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), " Approve"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: decision === "rejected" ? "secondary" : "outline",
									onClick: () => setMatchDecision(a.id, op.id, decision === "rejected" ? null : "rejected"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), " Reject"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: m.mentorNote ?? "",
							onChange: (e) => setMatchNote(a.id, op.id, e.target.value),
							placeholder: "Note for the applicant (why this fits, next steps, docs to prepare…)",
							rows: 2,
							className: "mt-3"
						})]
					}, m.opportunityId);
				})
			})
		]
	});
}
//#endregion
export { MentorCaseDetail as component };
