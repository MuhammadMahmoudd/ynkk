import { f as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useStore } from "./store-DyQeOvs3.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CYB-gyWu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mentor-6VW5JAxo.js
var import_jsx_runtime = require_jsx_runtime();
function MentorLayout() {
	const { mentors, activeMentorId, setActiveMentorId } = useStore();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b border-border/60 bg-secondary/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: "Signed in as"
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: mentors.find((m) => m.id === activeMentorId)?.name
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: activeMentorId,
				onValueChange: setActiveMentorId,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-8 w-[220px] text-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: mentors.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
					value: m.id,
					children: [
						m.name,
						" — ",
						m.focus
					]
				}, m.id)) })]
			})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})] });
}
//#endregion
export { MentorLayout as component };
