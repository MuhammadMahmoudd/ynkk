import { r as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { a as seedMentors, i as seedMatches, o as seedOpportunities, r as seedApplicants } from "./mockData-DHCWbxBq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-DyQeOvs3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var StoreCtx = import_react.createContext(null);
var LS_KEY = "ynk-proto-v1";
function loadFromStorage() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.localStorage.getItem(LS_KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function StoreProvider({ children }) {
	const [hydrated, setHydrated] = import_react.useState(false);
	const [role, setRole] = import_react.useState("applicant");
	const [lang, setLang] = import_react.useState("en");
	const [activeMentorId, setActiveMentorId] = import_react.useState(seedMentors[0].id);
	const [applicants, setApplicants] = import_react.useState(seedApplicants);
	const [opportunities, setOpportunities] = import_react.useState(seedOpportunities);
	const [matches, setMatches] = import_react.useState(seedMatches);
	const [mentors] = import_react.useState(seedMentors);
	import_react.useEffect(() => {
		const persisted = loadFromStorage();
		if (persisted) {
			if (persisted.role) setRole(persisted.role);
			if (persisted.lang) setLang(persisted.lang);
			if (persisted.activeMentorId) setActiveMentorId(persisted.activeMentorId);
			if (persisted.applicants) setApplicants(persisted.applicants);
			if (persisted.opportunities) setOpportunities(persisted.opportunities);
			if (persisted.matches) setMatches(persisted.matches);
		}
		setHydrated(true);
	}, []);
	import_react.useEffect(() => {
		if (!hydrated || typeof window === "undefined") return;
		window.localStorage.setItem(LS_KEY, JSON.stringify({
			role,
			lang,
			activeMentorId,
			applicants,
			opportunities,
			matches
		}));
	}, [
		hydrated,
		role,
		lang,
		activeMentorId,
		applicants,
		opportunities,
		matches
	]);
	const value = {
		role,
		setRole,
		lang,
		setLang,
		activeMentorId,
		setActiveMentorId,
		applicants,
		opportunities,
		matches,
		mentors,
		addApplicant: import_react.useCallback((a) => {
			setApplicants((prev) => [a, ...prev]);
			import("./mockData-DHCWbxBq.mjs").then((n) => n.n).then((n) => n.n).then(({ generateSeedMatches }) => {
				setMatches((prev) => [...prev, ...generateSeedMatches([a], opportunities)]);
			});
		}, [opportunities]),
		updateApplicantStatus: import_react.useCallback((id, status) => {
			setApplicants((prev) => prev.map((a) => a.id === id ? {
				...a,
				status
			} : a));
		}, []),
		assignMentor: import_react.useCallback((applicantId, mentorId) => {
			setApplicants((prev) => prev.map((a) => a.id === applicantId ? {
				...a,
				assignedMentorId: mentorId,
				status: mentorId ? a.status === "New" || a.status === "Triage" ? "Assigned" : a.status : a.status
			} : a));
		}, []),
		setMatchDecision: import_react.useCallback((applicantId, opportunityId, decision) => {
			setMatches((prev) => prev.map((m) => m.applicantId === applicantId && m.opportunityId === opportunityId ? {
				...m,
				mentorDecision: decision
			} : m));
		}, []),
		setMatchNote: import_react.useCallback((applicantId, opportunityId, note) => {
			setMatches((prev) => prev.map((m) => m.applicantId === applicantId && m.opportunityId === opportunityId ? {
				...m,
				mentorNote: note
			} : m));
		}, []),
		setMentorReport: import_react.useCallback((applicantId, report) => {
			setApplicants((prev) => prev.map((a) => a.id === applicantId ? {
				...a,
				mentorReport: report
			} : a));
		}, []),
		addOpportunity: import_react.useCallback((o) => {
			setOpportunities((prev) => [o, ...prev]);
		}, [])
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreCtx.Provider, {
		value,
		children
	});
}
function useStore() {
	const ctx = import_react.useContext(StoreCtx);
	if (!ctx) throw new Error("useStore must be used within StoreProvider");
	return ctx;
}
var DICT = {
	en: {
		"brand": "YNK Opportunities",
		"tagline": "Kurdish talent, matched to global opportunities.",
		"role.viewing": "Viewing as",
		"role.applicant": "Applicant",
		"role.admin": "Admin",
		"role.mentor": "Mentor",
		"nav.apply": "Apply",
		"nav.admin": "Admin",
		"nav.mentor": "Mentor",
		"lang.toggle": "کوردی",
		"form.step": "Step",
		"form.of": "of",
		"form.next": "Next",
		"form.back": "Back",
		"form.submit": "Submit application",
		"form.identity": "About you",
		"form.academic": "Academic background",
		"form.target": "Target programme",
		"form.language": "Languages",
		"form.experience": "Experience",
		"form.prefs": "Preferences",
		"form.funding": "Funding",
		"form.docs": "Documents",
		"form.done": "Application received",
		"form.doneBody": "Thanks — a mentor will review your case shortly."
	},
	ku: {
		"brand": "دەرفەتەکانی YNK",
		"tagline": "بەهرەی کوردی، لەگەڵ دەرفەتە جیهانییەکان دەبەستێینەوە.",
		"role.viewing": "بینین وەکو",
		"role.applicant": "داواکار",
		"role.admin": "بەڕێوەبەر",
		"role.mentor": "ڕاوێژکار",
		"nav.apply": "داواکاری",
		"nav.admin": "بەڕێوەبەر",
		"nav.mentor": "ڕاوێژکار",
		"lang.toggle": "English",
		"form.step": "هەنگاو",
		"form.of": "لە",
		"form.next": "دواتر",
		"form.back": "گەڕانەوە",
		"form.submit": "ناردنی داواکاری",
		"form.identity": "دەربارەی تۆ",
		"form.academic": "پێشینەی زانستی",
		"form.target": "بەرنامەی ئامانج",
		"form.language": "زمانەکان",
		"form.experience": "ئەزموون",
		"form.prefs": "هەڵبژاردەکان",
		"form.funding": "دارایی",
		"form.docs": "بەڵگەنامەکان",
		"form.done": "داواکارییەکەت وەرگیرا",
		"form.doneBody": "سوپاس — ڕاوێژکارێک بەم زووانە دۆسیەکەت پێداچوونەوەی بۆ دەکات."
	}
};
function useT() {
	const { lang } = useStore();
	return (k) => DICT[lang][k] ?? DICT.en[k] ?? k;
}
//#endregion
export { useStore as n, useT as r, StoreProvider as t };
