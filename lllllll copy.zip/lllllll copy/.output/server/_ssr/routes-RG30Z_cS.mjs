import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { r as useT } from "./store-DyQeOvs3.mjs";
import { d as LayoutGrid, f as GraduationCap, n as Users, x as ArrowRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-RG30Z_cS.js
var import_jsx_runtime = require_jsx_runtime();
function Landing() {
	const t = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "inline-flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-3 py-1 text-xs font-medium text-muted-foreground",
					children: "Clickable prototype · not a real database"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 text-4xl font-semibold tracking-tight text-foreground sm:text-6xl",
					children: t("brand")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg text-muted-foreground sm:text-xl",
					children: t("tagline")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-sm text-muted-foreground",
					children: "Walk the full journey end to end: apply as a student, triage the case as an admin, then approve a shortlist as a mentor. Use the role switcher in the header at any time."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12 grid gap-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleCard, {
					to: "/apply",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" }),
					title: "Applicant",
					body: "Multi-step intake form with Sorani/English and RTL support."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleCard, {
					to: "/admin",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-5" }),
					title: "Admin",
					body: "Case board, applicant detail, and mentor assignment."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleCard, {
					to: "/mentor",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5" }),
					title: "Mentor",
					body: "Matched shortlist with approve/reject and export view."
				})
			]
		})]
	});
}
function RoleCard({ to, icon, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "group flex flex-col justify-between rounded-xl border border-border bg-card p-6 transition-all hover:border-foreground/20 hover:shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-9 place-items-center rounded-md bg-secondary text-foreground",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 text-base font-semibold text-foreground",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: body
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex items-center text-sm font-medium text-foreground",
			children: ["Open", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ms-1 size-4 transition-transform group-hover:translate-x-0.5" })]
		})]
	});
}
//#endregion
export { Landing as component };
