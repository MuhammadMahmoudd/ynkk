import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mentor.cases._id-8ocbOuEq.js
var $$splitNotFoundComponentImporter = () => import("./mentor.cases._id-C53OgCmY.mjs");
var $$splitComponentImporter = () => import("./mentor.cases._id-BYDdgHHK.mjs");
var Route = createFileRoute("/mentor/cases/$id")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
//#endregion
export { Route as t };
