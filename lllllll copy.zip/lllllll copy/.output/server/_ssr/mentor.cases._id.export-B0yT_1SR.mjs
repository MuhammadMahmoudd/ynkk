import { M as notFound, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useStore } from "./store-DyQeOvs3.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { S as ArrowLeft, h as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./mentor.cases._id.export-BiHLJXf7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mentor.cases._id.export-B0yT_1SR.js
var import_jsx_runtime = require_jsx_runtime();
function ExportView() {
	const { id } = Route.useParams();
	const { applicants, opportunities, matches, mentors, activeMentorId } = useStore();
	const a = applicants.find((x) => x.id === id);
	if (!a) throw notFound();
	const mentor = mentors.find((m) => m.id === activeMentorId);
	const approved = matches.filter((m) => m.applicantId === a.id && m.mentorDecision === "approved").sort((x, y) => y.score - x.score);
	const text = buildPlainText(a.fullName, mentor?.name ?? "Mentor", approved, opportunities);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-6 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/mentor/cases/$id",
				params: { id: a.id },
				className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Back"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: () => {
					navigator.clipboard.writeText(text);
					toast.success("Copied to clipboard");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), " Copy"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-8 font-mono text-sm leading-relaxed",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-sans text-lg font-semibold",
					children: ["YNK Opportunities · Shortlist for ", a.fullName]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-sans text-xs text-muted-foreground",
					children: [
						"Prepared by ",
						mentor?.name,
						" · ",
						(/* @__PURE__ */ new Date()).toLocaleDateString()
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "my-4 border-border" }),
				approved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "No opportunities approved yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-5",
					children: approved.map((m, i) => {
						const op = opportunities.find((o) => o.id === m.opportunityId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-sans font-semibold",
								children: [
									i + 1,
									". ",
									op.name
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									op.provider,
									" · ",
									op.country,
									" · ",
									op.fundingType
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1",
								children: ["Deadline: ", new Date(op.deadline).toLocaleDateString()]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								"Fit: ",
								m.score,
								"/100"
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "break-all",
								children: ["Link: ", op.url]
							}),
							m.mentorNote && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 italic",
								children: ["Note: ", m.mentorNote]
							})
						] }, m.opportunityId);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: "my-4 border-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Reply to this message with any questions. Good luck!"
				})
			]
		})]
	});
}
function buildPlainText(applicantName, mentorName, approved, opportunities) {
	const lines = [];
	lines.push(`YNK Opportunities — Shortlist for ${applicantName}`);
	lines.push(`Prepared by ${mentorName} · ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`);
	lines.push("");
	approved.forEach((m, i) => {
		const op = opportunities.find((o) => o.id === m.opportunityId);
		if (!op) return;
		lines.push(`${i + 1}. ${op.name} (${op.provider})`);
		lines.push(`   ${op.country} · ${op.fundingType}`);
		lines.push(`   Deadline: ${new Date(op.deadline).toLocaleDateString()}`);
		lines.push(`   Fit: ${m.score}/100`);
		lines.push(`   ${op.url}`);
		if (m.mentorNote) lines.push(`   Note: ${m.mentorNote}`);
		lines.push("");
	});
	return lines.join("\n");
}
//#endregion
export { ExportView as component };
