import { r as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as CASE_STATUSES } from "./mockData-DHCWbxBq.mjs";
import { n as useStore } from "./store-DyQeOvs3.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-CYHPIWi7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminBoard() {
	const { applicants, updateApplicantStatus, mentors } = useStore();
	const [dragging, setDragging] = (0, import_react.useState)(null);
	const byStatus = (s) => applicants.filter((a) => a.status === s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-[1400px] px-4 py-6 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex items-end justify-between",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-semibold",
				children: "Case board"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [applicants.length, " applicants · drag between columns to update status."]
			})] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 gap-3 md:grid-cols-3 lg:grid-cols-7",
			children: CASE_STATUSES.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-[300px] flex-col rounded-lg border border-border bg-secondary/30 p-3",
				onDragOver: (e) => e.preventDefault(),
				onDrop: (e) => {
					e.preventDefault();
					const id = e.dataTransfer.getData("text/plain") || dragging;
					if (id) updateApplicantStatus(id, status);
					setDragging(null);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
						children: status
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: byStatus(status).length
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [byStatus(status).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaseCard, {
						applicant: a,
						mentorName: mentors.find((m) => m.id === a.assignedMentorId)?.name,
						onDragStart: () => setDragging(a.id)
					}, a.id)), byStatus(status).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-md border border-dashed border-border/60 p-4 text-center text-xs text-muted-foreground",
						children: "Empty"
					})]
				})]
			}, status))
		})]
	});
}
function CaseCard({ applicant, mentorName, onDragStart }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/admin/cases/$id",
		params: { id: applicant.id },
		draggable: true,
		onDragStart: (e) => {
			e.dataTransfer.setData("text/plain", applicant.id);
			onDragStart();
		},
		className: "block cursor-grab rounded-md border border-border bg-card p-3 text-sm shadow-sm transition-shadow hover:shadow active:cursor-grabbing",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: applicant.fullName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						applicant.targetLevel,
						" · ",
						applicant.targetField
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					variant: "outline",
					className: "shrink-0 text-[10px]",
					children: ["GPA ", applicant.gpa.toFixed(1)]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-1",
				children: applicant.targetCountries.slice(0, 3).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground",
					children: c
				}, c))
			}),
			mentorName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-[11px] text-muted-foreground",
				children: ["Mentor: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground",
					children: mentorName
				})]
			})
		]
	});
}
//#endregion
export { AdminBoard as component };
