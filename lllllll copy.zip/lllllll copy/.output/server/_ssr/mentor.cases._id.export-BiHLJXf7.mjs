import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mentor.cases._id.export-BiHLJXf7.js
var $$splitNotFoundComponentImporter = () => import("./mentor.cases._id.export-DrWxQdZA.mjs");
var $$splitComponentImporter = () => import("./mentor.cases._id.export-B0yT_1SR.mjs");
var Route = createFileRoute("/mentor/cases/$id/export")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
//#endregion
export { Route as t };
