import { f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-D1B2WLO2.js
var import_jsx_runtime = require_jsx_runtime();
function AdminLayout() {
	const path = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b border-border/60 bg-secondary/20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex max-w-7xl items-center gap-1 px-4 sm:px-6",
			children: [{
				to: "/admin",
				label: "Case board",
				exact: true
			}, {
				to: "/admin/opportunities",
				label: "Opportunities",
				exact: false
			}].map((t) => {
				const active = t.exact ? path === t.to : path.startsWith(t.to);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: t.to,
					className: `border-b-2 px-3 py-3 text-sm transition-colors ${active ? "border-foreground text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`,
					children: t.label
				}, t.to);
			})
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})] });
}
//#endregion
export { AdminLayout as component };
