import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useStore } from "./store-DyQeOvs3.mjs";
import { x as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mentor.index-NBu8OVkt.js
var import_jsx_runtime = require_jsx_runtime();
function MentorCases() {
	const { applicants, activeMentorId, matches } = useStore();
	const mine = applicants.filter((a) => a.assignedMentorId === activeMentorId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl px-4 py-6 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-semibold",
				children: "My cases"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [mine.length, " assigned to you."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-6 grid gap-3",
				children: [mine.map((a) => {
					const ms = matches.filter((m) => m.applicantId === a.id);
					const approved = ms.filter((m) => m.mentorDecision === "approved").length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/mentor/cases/$id",
						params: { id: a.id },
						className: "flex items-center justify-between rounded-xl border border-border bg-card p-4 transition-shadow hover:shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: a.fullName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								a.targetLevel,
								" · ",
								a.targetField,
								" · ",
								a.targetCountries.join(", ")
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: a.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [
										approved,
										"/",
										ms.length,
										" approved"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted-foreground" })
							]
						})]
					}) }, a.id);
				}), mine.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground",
					children: "No cases assigned. Switch mentor in the bar above, or assign from Admin."
				})]
			})
		]
	});
}
//#endregion
export { MentorCases as component };
