import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.cases._id-DaKkVORZ.js
var $$splitNotFoundComponentImporter = () => import("./admin.cases._id-CW8SJ0gS.mjs");
var $$splitComponentImporter = () => import("./admin.cases._id-Lfimno6W.mjs");
var Route = createFileRoute("/admin/cases/$id")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
//#endregion
export { Route as t };
