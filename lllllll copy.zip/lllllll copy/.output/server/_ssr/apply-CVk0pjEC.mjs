import { r as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useStore, r as useT } from "./store-DyQeOvs3.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { _ as CircleCheck, i as Trash2, m as ExternalLink, o as Plus, r as Upload } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CYB-gyWu.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { n as Root$1, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/apply-CVk0pjEC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	className: cn("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full w-full flex-1 bg-primary transition-all",
		style: { transform: `translateX(-${100 - (value || 0)}%)` }
	})
}));
Progress.displayName = Root$1.displayName;
var DEGREE_LEVELS = [
	"Diploma",
	"Bachelor",
	"Master",
	"PhD",
	"Short course"
];
var EXPERIENCE_OPTIONS = [
	"Research assistant",
	"Published research",
	"Internship",
	"Volunteer / NGO work",
	"Founded a startup",
	"Competition winner",
	"Teaching",
	"Leadership role"
];
var LANGUAGE_EXAMS = [
	"IELTS",
	"TOEFL",
	"PTE",
	"Duolingo",
	"Cambridge",
	"Previous study in English",
	"Other"
];
var COUNTRIES = [
	"United Kingdom",
	"Germany",
	"Netherlands",
	"Sweden",
	"United States",
	"France",
	"Japan",
	"China",
	"Turkey",
	"Austria",
	"Saudi Arabia"
];
var FUNDING_PREFERENCE_OPTIONS = [
	"Full scholarship only",
	"Self-funded",
	"Open to both"
];
var EMPTY = {
	fullName: "",
	email: "",
	phone: "",
	city: "",
	gender: "F",
	dateOfBirth: "",
	degreeLevel: "Bachelor",
	field: "",
	university: "",
	gpa: "",
	studyStartDate: "",
	studyGraduationDate: "",
	additionalDegrees: [],
	targetLevel: "Master",
	targetField: "",
	targetCountries: [
		"",
		"",
		""
	],
	targetRegionsText: "",
	targetUniversitiesText: "",
	englishLevel: "B2",
	languageTests: [{
		exam: "IELTS",
		score: "",
		details: ""
	}],
	experienceEntries: [{
		category: EXPERIENCE_OPTIONS[0],
		role: "",
		organization: "",
		location: "",
		period: "",
		collaborators: "",
		details: ""
	}],
	fundingPreference: "Full scholarship only",
	notes: "",
	documents: [],
	documentUploadSlots: 1
};
function ApplyPage() {
	const t = useT();
	const { addApplicant, lang } = useStore();
	const [step, setStep] = (0, import_react.useState)(0);
	const [data, setData] = (0, import_react.useState)(EMPTY);
	const [done, setDone] = (0, import_react.useState)(false);
	const steps = (0, import_react.useMemo)(() => [
		t("form.identity"),
		t("form.academic"),
		t("form.target"),
		t("form.language"),
		t("form.experience"),
		t("form.funding"),
		t("form.docs")
	], [lang]);
	const set = (k, v) => setData((d) => ({
		...d,
		[k]: v
	}));
	const addDegree = () => {
		set("additionalDegrees", [...data.additionalDegrees, {
			level: "Bachelor",
			field: "",
			university: "",
			startDate: "",
			graduationDate: "",
			gpa: ""
		}]);
	};
	const updateDegree = (index, key, value) => {
		const next = [...data.additionalDegrees];
		next[index] = {
			...next[index],
			[key]: value
		};
		set("additionalDegrees", next);
	};
	const updateCountry = (index, value) => {
		const next = [...data.targetCountries];
		next[index] = value;
		set("targetCountries", next);
	};
	const addCountryChip = (country) => {
		const next = [...data.targetCountries];
		const idx = next.findIndex((entry) => !entry.trim());
		if (idx >= 0) next[idx] = country;
		else next[0] = country;
		set("targetCountries", next.slice(0, 3));
	};
	const addLanguageTest = () => {
		set("languageTests", [...data.languageTests, {
			exam: "IELTS",
			score: "",
			details: ""
		}]);
	};
	const updateLanguageTest = (index, key, value) => {
		const next = [...data.languageTests];
		next[index] = {
			...next[index],
			[key]: value
		};
		set("languageTests", next);
	};
	const addExperienceEntry = () => {
		set("experienceEntries", [...data.experienceEntries, {
			category: EXPERIENCE_OPTIONS[0],
			role: "",
			organization: "",
			location: "",
			period: "",
			collaborators: "",
			details: ""
		}]);
	};
	const updateExperienceEntry = (index, key, value) => {
		const next = [...data.experienceEntries];
		next[index] = {
			...next[index],
			[key]: value
		};
		set("experienceEntries", next);
	};
	const addDocumentUpload = () => {
		set("documentUploadSlots", data.documentUploadSlots + 1);
	};
	const handleDocumentUpload = (name, kind, size, fileType) => {
		if (!name) return;
		if (size && size > 5 * 1024 * 1024) {
			toast.error("Documents must be 5 MB or smaller.");
			return;
		}
		if (fileType && fileType !== "application/pdf" && !name.toLowerCase().endsWith(".pdf")) {
			toast.error("Only PDF files are accepted for uploads.");
			return;
		}
		set("documents", [...data.documents, {
			name,
			kind,
			size,
			fileType
		}]);
		toast.success(`Added ${name}`);
	};
	const submit = () => {
		const a = {
			id: `a_${Date.now()}`,
			fullName: data.fullName || "Untitled applicant",
			email: data.email,
			phone: data.phone,
			country: "Iraq",
			city: data.city,
			gender: data.gender,
			dateOfBirth: data.dateOfBirth,
			degreeLevel: data.degreeLevel,
			field: data.field,
			university: data.university,
			gpa: parseFloat(data.gpa) || 0,
			targetLevel: data.targetLevel,
			targetField: data.targetField,
			targetCountries: data.targetCountries.filter(Boolean),
			targetRegions: data.targetRegionsText.split(/[\n,]+/).map((x) => x.trim()).filter(Boolean),
			targetUniversities: data.targetUniversitiesText.split(/[\n,]+/).map((x) => x.trim()).filter(Boolean),
			languages: [{
				name: "Kurdish",
				level: "C2"
			}, {
				name: "English",
				level: data.englishLevel
			}],
			languageTests: data.languageTests.filter((entry) => entry.exam || entry.score || entry.details || entry.fileName),
			ielts: data.languageTests.find((entry) => entry.exam === "IELTS")?.score ? parseFloat(data.languageTests.find((entry) => entry.exam === "IELTS")?.score || "") : void 0,
			experience: data.experienceEntries.map((entry) => entry.category).filter(Boolean),
			experienceDetails: data.experienceEntries.filter((entry) => entry.category || entry.role || entry.organization || entry.details),
			fundingPreference: [data.fundingPreference],
			notes: data.notes,
			documents: data.documents,
			studyStartDate: data.studyStartDate || void 0,
			studyGraduationDate: data.studyGraduationDate || void 0,
			additionalDegrees: data.additionalDegrees.filter((entry) => entry.level || entry.field || entry.university || entry.gpa),
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			status: "New"
		};
		addApplicant(a);
		setDone(true);
		toast.success(t("form.done"));
	};
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-2xl px-4 py-16 sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid size-14 place-items-center rounded-full bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-7" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-2xl font-semibold",
					children: t("form.done")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: t("form.doneBody")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin",
							children: "See it in Admin"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => {
							setData(EMPTY);
							setStep(0);
							setDone(false);
						},
						children: "Submit another"
					})]
				})
			]
		})
	});
	const pct = (step + 1) / steps.length * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-10 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					t("form.step"),
					" ",
					step + 1,
					" ",
					t("form.of"),
					" ",
					steps.length,
					" — ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: steps[step]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [Math.round(pct), "%"] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
				value: pct,
				className: "mt-2 h-1.5"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-6",
			children: [
				step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Full name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: data.fullName,
								onChange: (e) => set("fullName", e.target.value),
								placeholder: "e.g. Shan Ibrahim"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									value: data.email,
									onChange: (e) => set("email", e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: data.phone,
									onChange: (e) => set("phone", e.target.value),
									placeholder: "+964 …"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "City",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: data.city,
										onChange: (e) => set("city", e.target.value)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Gender",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: data.gender,
										onValueChange: (v) => set("gender", v),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "F",
												children: "Female"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "M",
												children: "Male"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Other",
												children: "Other"
											})
										] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Date of birth",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: data.dateOfBirth,
										onChange: (e) => set("dateOfBirth", e.target.value)
									})
								})
							]
						})
					]
				}),
				step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Current level",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: data.degreeLevel,
									onValueChange: (v) => set("degreeLevel", v),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: DEGREE_LEVELS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: d,
										children: d
									}, d)) })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Field of study",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: data.field,
									onChange: (e) => set("field", e.target.value),
									placeholder: "e.g. Computer Science"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "University",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: data.university,
								onChange: (e) => set("university", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "GPA (out of 4)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.1",
								min: "0",
								max: "4",
								value: data.gpa,
								onChange: (e) => set("gpa", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "https://www.gpacalculator.io",
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex items-center gap-1 text-sm text-primary hover:underline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" }), " Open GPA calculator"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Study start date",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: data.studyStartDate,
									onChange: (e) => set("studyStartDate", e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Expected graduation date",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: data.studyGraduationDate,
									onChange: (e) => set("studyGraduationDate", e.target.value)
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-border p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: "Additional degrees (optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									size: "sm",
									onClick: addDegree,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-2 size-4" }), " Add degree"]
								})]
							}), data.additionalDegrees.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "You can add another degree if you have one."
							}) : data.additionalDegrees.map((degree, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 rounded-md border border-border/70 bg-secondary/20 p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-3 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm font-medium",
											children: ["Degree ", index + 2]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "ghost",
											size: "sm",
											onClick: () => set("additionalDegrees", data.additionalDegrees.filter((_, i) => i !== index)),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-3 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Level",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value: degree.level,
												onValueChange: (v) => updateDegree(index, "level", v),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: DEGREE_LEVELS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: d,
													children: d
												}, d)) })]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Field",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: degree.field,
												onChange: (e) => updateDegree(index, "field", e.target.value)
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "University",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: degree.university,
											onChange: (e) => updateDegree(index, "university", e.target.value)
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 grid gap-3 sm:grid-cols-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Start date",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "date",
													value: degree.startDate,
													onChange: (e) => updateDegree(index, "startDate", e.target.value)
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Graduation date",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "date",
													value: degree.graduationDate,
													onChange: (e) => updateDegree(index, "graduationDate", e.target.value)
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "GPA",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													step: "0.1",
													min: "0",
													max: "4",
													value: degree.gpa,
													onChange: (e) => updateDegree(index, "gpa", e.target.value)
												})
											})
										]
									})
								]
							}, index))]
						})
					]
				}),
				step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Target level",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: data.targetLevel,
									onValueChange: (v) => set("targetLevel", v),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: DEGREE_LEVELS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: d,
										children: d
									}, d)) })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Target field",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: data.targetField,
									onChange: (e) => set("targetField", e.target.value),
									placeholder: "e.g. Data Science"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: data.targetCountries.map((country, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `Target country ${index + 1}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: country,
									onChange: (e) => updateCountry(index, e.target.value),
									placeholder: "Type a country"
								})
							}, index))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: COUNTRIES.map((country) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => addCountryChip(country),
								className: "rounded-full border border-border bg-background px-3 py-1 text-xs text-muted-foreground transition-colors hover:bg-secondary",
								children: country
							}, country))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Target continent / region (optional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: data.targetRegionsText,
								onChange: (e) => set("targetRegionsText", e.target.value),
								placeholder: "e.g. Europe, MENA, Asia"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Target universities (optional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: data.targetUniversitiesText,
								onChange: (e) => set("targetUniversitiesText", e.target.value),
								placeholder: "Type each university on a new line"
							})
						})
					]
				}),
				step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "English level (CEFR)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: data.englishLevel,
							onValueChange: (v) => set("englishLevel", v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
								"A2",
								"B1",
								"B2",
								"C1",
								"C2"
							].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: x,
								children: x
							}, x)) })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-border p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "Language scores / other exams"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								onClick: addLanguageTest,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-2 size-4" }), " Add another test"]
							})]
						}), data.languageTests.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 rounded-md border border-border/70 bg-secondary/20 p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Exam type",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: entry.exam,
										onValueChange: (value) => updateLanguageTest(index, "exam", value),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: LANGUAGE_EXAMS.map((exam) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: exam,
											children: exam
										}, exam)) })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid gap-3 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Score / band / result",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: entry.score,
											onChange: (e) => updateLanguageTest(index, "score", e.target.value),
											placeholder: "e.g. 7.0 or 95"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Details",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: entry.details,
											onChange: (e) => updateLanguageTest(index, "details", e.target.value),
											placeholder: "e.g. taken in 2024"
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-3 flex cursor-pointer items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-secondary",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }),
										" Upload score file (PDF, max 5MB)",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "application/pdf",
											className: "hidden",
											onChange: (e) => {
												const file = e.target.files?.[0];
												if (file) {
													handleDocumentUpload(file.name, "Language score", file.size, file.type);
													updateLanguageTest(index, "fileName", file.name);
													e.target.value = "";
												}
											}
										})
									]
								}),
								entry.fileName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-muted-foreground",
									children: ["Uploaded: ", entry.fileName]
								})
							]
						}, index))]
					})]
				}),
				step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Add each experience one by one with more detail."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							onClick: addExperienceEntry,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-2 size-4" }), " Add experience"]
						})]
					}), data.experienceEntries.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-border p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Experience type",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: entry.category,
									onValueChange: (value) => updateExperienceEntry(index, "category", value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: EXPERIENCE_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: option,
										children: option
									}, option)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-3 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Role / title",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: entry.role,
										onChange: (e) => updateExperienceEntry(index, "role", e.target.value)
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Organization",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: entry.organization,
										onChange: (e) => updateExperienceEntry(index, "organization", e.target.value)
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-3 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Where",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: entry.location,
										onChange: (e) => updateExperienceEntry(index, "location", e.target.value)
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "When / period",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: entry.period,
										onChange: (e) => updateExperienceEntry(index, "period", e.target.value)
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "With whom / collaborators",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: entry.collaborators,
									onChange: (e) => updateExperienceEntry(index, "collaborators", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Details",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 3,
									value: entry.details,
									onChange: (e) => updateExperienceEntry(index, "details", e.target.value)
								})
							})
						]
					}, index))]
				}),
				step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Funding preference",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: data.fundingPreference,
							onValueChange: (value) => set("fundingPreference", value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: FUNDING_PREFERENCE_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: option,
								children: option
							}, option)) })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Anything else we should know?",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 4,
							value: data.notes,
							onChange: (e) => set("notes", e.target.value)
						})
					})]
				}),
				step === 6 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Upload as many PDF documents as you need. Each file must be 5 MB or smaller."
						}),
						Array.from({ length: data.documentUploadSlots }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FakeUpload, { onFile: (name, kind, size, fileType) => handleDocumentUpload(name, kind, size, fileType) }, index)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							onClick: addDocumentUpload,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-2 size-4" }), " Add another document"]
						}),
						data.documents.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-2",
							children: data.documents.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between rounded-md border border-border bg-secondary/30 px-3 py-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-primary" }), d.name]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "secondary",
									children: d.kind
								})]
							}, i))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						disabled: step === 0,
						onClick: () => setStep((s) => Math.max(0, s - 1)),
						children: t("form.back")
					}), step < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setStep((s) => Math.min(steps.length - 1, s + 1)),
						children: t("form.next")
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: submit,
						children: t("form.submit")
					})]
				})
			]
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "text-xs font-medium text-muted-foreground",
			children: label
		}), children]
	});
}
function FakeUpload({ onFile }) {
	const [kind, setKind] = (0, import_react.useState)("CV");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 rounded-lg border border-dashed border-border p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: kind,
				onValueChange: setKind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "w-[180px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
					"CV",
					"Transcript",
					"Passport",
					"Writing sample",
					"Portfolio",
					"Other"
				].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: k,
					children: k
				}, k)) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "inline-flex cursor-pointer items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm hover:bg-secondary",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }),
					" Choose file",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						className: "hidden",
						accept: "application/pdf",
						onChange: (e) => {
							const f = e.target.files?.[0];
							if (f) {
								onFile(f.name, kind, f.size, f.type);
								e.target.value = "";
							}
						}
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "PDF only, max 5 MB. Files are still demo-only."
		})]
	});
}
//#endregion
export { ApplyPage as component };
