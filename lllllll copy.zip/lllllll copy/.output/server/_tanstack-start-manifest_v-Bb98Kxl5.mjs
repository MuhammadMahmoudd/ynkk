//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bb98Kxl5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/apply",
			"/mentor"
		],
		preloads: [
			"/assets/index-sNeFA6zy.js",
			"/assets/jsx-runtime-DUAcabCT.js",
			"/assets/react-DbyrFoBd.js",
			"/assets/useStore-D3Gt4bZ9.js",
			"/assets/matchContext-BS3oW0st.js",
			"/assets/link-r0N7lJCc.js",
			"/assets/mockData-Cp5wSYfW.js",
			"/assets/utils-B6KiDbIe.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-sNeFA6zy.js"
		} }]
	},
	"/": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DHsS6SPX.js",
			"/assets/arrow-right-D5uDNaZG.js",
			"/assets/graduation-cap-7cII5UIv.js"
		]
	},
	"/admin": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/admin.tsx",
		children: [
			"/admin/opportunities",
			"/admin/",
			"/admin/cases/$id"
		],
		preloads: ["/assets/admin-7fI3JHYv.js"]
	},
	"/apply": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/apply.tsx",
		children: void 0,
		preloads: [
			"/assets/apply-D3dQsEpr.js",
			"/assets/badge-gb2F7wnX.js",
			"/assets/input-Cw8iG4zf.js",
			"/assets/textarea-DNwI_kdB.js"
		]
	},
	"/mentor": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/mentor.tsx",
		children: ["/mentor/", "/mentor/cases/$id"],
		preloads: ["/assets/mentor-DIV7BHeG.js"]
	},
	"/admin/opportunities": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/admin.opportunities.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.opportunities-BT8nMSKR.js",
			"/assets/badge-gb2F7wnX.js",
			"/assets/input-Cw8iG4zf.js"
		]
	},
	"/admin/": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/admin.index.tsx",
		children: void 0,
		preloads: ["/assets/admin.index-Dtu8Rsm9.js", "/assets/badge-gb2F7wnX.js"]
	},
	"/mentor/": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/mentor.index.tsx",
		children: void 0,
		preloads: [
			"/assets/mentor.index-DIYGD8ea.js",
			"/assets/arrow-right-D5uDNaZG.js",
			"/assets/badge-gb2F7wnX.js"
		]
	},
	"/admin/cases/$id": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/admin.cases.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.cases._id-DgxSMABO.js",
			"/assets/admin.cases._id-DsLtdf2S.js",
			"/assets/arrow-left-CkG5HAZ6.js",
			"/assets/file-text-D7Z5Fl1Y.js",
			"/assets/graduation-cap-7cII5UIv.js",
			"/assets/badge-gb2F7wnX.js"
		]
	},
	"/mentor/cases/$id": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/mentor.cases.$id.tsx",
		children: ["/mentor/cases/$id/export"],
		preloads: [
			"/assets/mentor.cases._id-C2_9jTW1.js",
			"/assets/arrow-left-CkG5HAZ6.js",
			"/assets/file-text-D7Z5Fl1Y.js",
			"/assets/badge-gb2F7wnX.js",
			"/assets/textarea-DNwI_kdB.js",
			"/assets/mentor.cases._id-DgxSMABO.js"
		]
	},
	"/mentor/cases/$id/export": {
		filePath: "/Users/mohammedsurchy/Downloads/lllllll/src/routes/mentor.cases.$id.export.tsx",
		children: void 0,
		preloads: ["/assets/mentor.cases._id.export-DPZN_Cvm.js", "/assets/mentor.cases._id.export-DgxSMABO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
