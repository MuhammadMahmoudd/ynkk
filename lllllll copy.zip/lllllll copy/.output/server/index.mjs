globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-16T12:56:49.098Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/admin-7fI3JHYv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"32f-Mdn5/VheA9JRM3CTR7o8KOpK+kQ\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 815,
		"path": "../public/assets/admin-7fI3JHYv.js"
	},
	"/assets/admin.cases._id-DgxSMABO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c6-X0Zl5k5lZcPKFWFVDLlQOMVMnV0\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 198,
		"path": "../public/assets/admin.cases._id-DgxSMABO.js"
	},
	"/assets/admin.cases._id-DsLtdf2S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20ca-BrWUo/TSK62oRk1tN4bdBWCi9S0\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 8394,
		"path": "../public/assets/admin.cases._id-DsLtdf2S.js"
	},
	"/assets/admin.index-Dtu8Rsm9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b5b-EYE0Up4lZaJpMINRYD43lrbSY4Q\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 2907,
		"path": "../public/assets/admin.index-Dtu8Rsm9.js"
	},
	"/assets/admin.opportunities-BT8nMSKR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"939-bHDfcWyx1WzYl6I0mXG9lf56pcQ\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 2361,
		"path": "../public/assets/admin.opportunities-BT8nMSKR.js"
	},
	"/assets/arrow-left-CkG5HAZ6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-+4aOkzFMkiZzCXgBB4w8wUnNEks\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 154,
		"path": "../public/assets/arrow-left-CkG5HAZ6.js"
	},
	"/assets/arrow-right-D5uDNaZG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-SFSOxN8oobd2erA6kyYAMzHCMxc\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 154,
		"path": "../public/assets/arrow-right-D5uDNaZG.js"
	},
	"/assets/graduation-cap-7cII5UIv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"141-T3vGhAkMGKleQPlXvLpHFO2+ZYA\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 321,
		"path": "../public/assets/graduation-cap-7cII5UIv.js"
	},
	"/assets/file-text-D7Z5Fl1Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"176-LrFF3ZpxV3BhHgP1YHzJjSaRjV4\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 374,
		"path": "../public/assets/file-text-D7Z5Fl1Y.js"
	},
	"/assets/input-Cw8iG4zf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"289-wLg20VN1L6T2RJ77qPj0nXmzCXU\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 649,
		"path": "../public/assets/input-Cw8iG4zf.js"
	},
	"/assets/matchContext-BS3oW0st.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"326-rL8+aq2gkwd879JvCkY+lC6BraQ\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 806,
		"path": "../public/assets/matchContext-BS3oW0st.js"
	},
	"/assets/jsx-runtime-DUAcabCT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"42a-6CWT3JsIzkgrrMo5qQ6L1UWEbvM\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 1066,
		"path": "../public/assets/jsx-runtime-DUAcabCT.js"
	},
	"/assets/mentor-DIV7BHeG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"399-2Y/13ICSETxrs8ElRi0OjsUIfSU\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 921,
		"path": "../public/assets/mentor-DIV7BHeG.js"
	},
	"/assets/link-r0N7lJCc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"111b-a27H1Ct5yKVN2EJqCKJXJdsnU6Y\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 4379,
		"path": "../public/assets/link-r0N7lJCc.js"
	},
	"/assets/mentor.cases._id-DgxSMABO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c6-X0Zl5k5lZcPKFWFVDLlQOMVMnV0\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 198,
		"path": "../public/assets/mentor.cases._id-DgxSMABO.js"
	},
	"/assets/apply-D3dQsEpr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"52e8-hJP+Kwr0AxrAx2fQY3lBpC047S0\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 21224,
		"path": "../public/assets/apply-D3dQsEpr.js"
	},
	"/assets/mentor.cases._id.export-DPZN_Cvm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c82-VM7E1qNeaVp8jvtokdIT/bLLQQM\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 3202,
		"path": "../public/assets/mentor.cases._id.export-DPZN_Cvm.js"
	},
	"/assets/badge-gb2F7wnX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"346-lmDXBCmb2/nPDrd76S+jN3Qgxuk\"",
		"mtime": "2026-07-16T12:56:48.844Z",
		"size": 838,
		"path": "../public/assets/badge-gb2F7wnX.js"
	},
	"/assets/index-sNeFA6zy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a2b9-mOOFJjpy+966VfgACBpRA9yFOvY\"",
		"mtime": "2026-07-16T12:56:48.841Z",
		"size": 434873,
		"path": "../public/assets/index-sNeFA6zy.js"
	},
	"/assets/mentor.cases._id-C2_9jTW1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18ef-+g1k2pTZjYkukcJLwuJFmI3Wua8\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 6383,
		"path": "../public/assets/mentor.cases._id-C2_9jTW1.js"
	},
	"/assets/mockData-Cp5wSYfW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2fd1-TUWqkq6PNP0UW92WWXpWsRB2CdQ\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 12241,
		"path": "../public/assets/mockData-Cp5wSYfW.js"
	},
	"/assets/mentor.index-DIYGD8ea.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6b5-0QV3vGzVvzEUlvmCu8aXfwmzp/M\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 1717,
		"path": "../public/assets/mentor.index-DIYGD8ea.js"
	},
	"/assets/react-DbyrFoBd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d67-mi2wZUq39ijUTZDJBuXqznfenBA\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 7527,
		"path": "../public/assets/react-DbyrFoBd.js"
	},
	"/assets/mentor.cases._id.export-DgxSMABO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c6-X0Zl5k5lZcPKFWFVDLlQOMVMnV0\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 198,
		"path": "../public/assets/mentor.cases._id.export-DgxSMABO.js"
	},
	"/assets/routes-DHsS6SPX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b42-JBd0LCFml2oAiPzsfmj9TldM79Q\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 2882,
		"path": "../public/assets/routes-DHsS6SPX.js"
	},
	"/assets/textarea-DNwI_kdB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"223-POBivPADQx5J6b/L02GT9BJOfpQ\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 547,
		"path": "../public/assets/textarea-DNwI_kdB.js"
	},
	"/assets/styles-BwR6_cbi.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1351a-X3dn4OP3UzAKURLUyFi9YGfcYko\"",
		"mtime": "2026-07-16T12:56:48.846Z",
		"size": 79130,
		"path": "../public/assets/styles-BwR6_cbi.css"
	},
	"/assets/useStore-D3Gt4bZ9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"58b2-kZsZP3zCCD2oW5pV1BGSyx0jjGA\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 22706,
		"path": "../public/assets/useStore-D3Gt4bZ9.js"
	},
	"/assets/utils-B6KiDbIe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a7d-iNkBSvaSyIjvZOzWoTvEa49qwcI\"",
		"mtime": "2026-07-16T12:56:48.845Z",
		"size": 27261,
		"path": "../public/assets/utils-B6KiDbIe.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_u4tbFY = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_u4tbFY
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
